package com.example.advancedcalculator;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

public class CalculatorFragment extends Fragment {

    private TextView tvExpression, tvResult;
    private String currentNumber = "";
    private String oldNumber = "";
    private String operator = "";
    private boolean isNewNumber = true;
    private double memoryValue = 0;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_calculator, container, false);

        tvExpression = view.findViewById(R.id.tvExpression);
        tvResult = view.findViewById(R.id.tvResult);

        setupButtons(view);
        return view;
    }

    private void setupButtons(View view) {
        // Number buttons
        view.findViewById(R.id.btn0).setOnClickListener(v -> addNumber("0"));
        view.findViewById(R.id.btn1).setOnClickListener(v -> addNumber("1"));
        view.findViewById(R.id.btn2).setOnClickListener(v -> addNumber("2"));
        view.findViewById(R.id.btn3).setOnClickListener(v -> addNumber("3"));
        view.findViewById(R.id.btn4).setOnClickListener(v -> addNumber("4"));
        view.findViewById(R.id.btn5).setOnClickListener(v -> addNumber("5"));
        view.findViewById(R.id.btn6).setOnClickListener(v -> addNumber("6"));
        view.findViewById(R.id.btn7).setOnClickListener(v -> addNumber("7"));
        view.findViewById(R.id.btn8).setOnClickListener(v -> addNumber("8"));
        view.findViewById(R.id.btn9).setOnClickListener(v -> addNumber("9"));

        // Basic operator buttons
        view.findViewById(R.id.btnAdd).setOnClickListener(v -> setOperator("+"));
        view.findViewById(R.id.btnSubtract).setOnClickListener(v -> setOperator("-"));
        view.findViewById(R.id.btnMultiply).setOnClickListener(v -> setOperator("*"));
        view.findViewById(R.id.btnDivide).setOnClickListener(v -> setOperator("/"));

        // Other basic buttons
        view.findViewById(R.id.btnDecimal).setOnClickListener(v -> addDecimal());
        view.findViewById(R.id.btnEquals).setOnClickListener(v -> calculate());
        view.findViewById(R.id.btnClearAll).setOnClickListener(v -> clearAll());
        view.findViewById(R.id.btnClearEntry).setOnClickListener(v -> clearEntry());
        view.findViewById(R.id.btnBackspace).setOnClickListener(v -> backspace());
        view.findViewById(R.id.btnPercent).setOnClickListener(v -> percentage());

        // Scientific functions
        view.findViewById(R.id.btnSqrt).setOnClickListener(v -> squareRoot());
        view.findViewById(R.id.btnSquare).setOnClickListener(v -> square());
        view.findViewById(R.id.btnCube).setOnClickListener(v -> cube());
        view.findViewById(R.id.btnPower).setOnClickListener(v -> power());

        // Trigonometric functions
        view.findViewById(R.id.btnSin).setOnClickListener(v -> sin());
        view.findViewById(R.id.btnCos).setOnClickListener(v -> cos());
        view.findViewById(R.id.btnTan).setOnClickListener(v -> tan());
        view.findViewById(R.id.btnLog).setOnClickListener(v -> log());

        // Memory functions
        view.findViewById(R.id.btnMC).setOnClickListener(v -> memoryClear());
        view.findViewById(R.id.btnMR).setOnClickListener(v -> memoryRecall());
        view.findViewById(R.id.btnMPlus).setOnClickListener(v -> memoryAdd());
        view.findViewById(R.id.btnMMinus).setOnClickListener(v -> memorySubtract());
    }

    private void addNumber(String num) {
        if (isNewNumber) {
            currentNumber = "";
            isNewNumber = false;
        }
        if (currentNumber.equals("0") && !num.equals(".")) {
            currentNumber = num;
        } else {
            currentNumber += num;
        }
        tvExpression.setText(currentNumber);
    }

    private void addDecimal() {
        if (isNewNumber) {
            currentNumber = "0";
            isNewNumber = false;
        }
        if (!currentNumber.contains(".")) {
            currentNumber += ".";
            tvExpression.setText(currentNumber);
        }
    }

    private void setOperator(String op) {
        if (!currentNumber.isEmpty()) {
            oldNumber = currentNumber;
            operator = op;
            isNewNumber = true;
            tvResult.setText(oldNumber + " " + operator);
        }
    }

    private void calculate() {
        if (!oldNumber.isEmpty() && !currentNumber.isEmpty()) {
            double num1 = Double.parseDouble(oldNumber);
            double num2 = Double.parseDouble(currentNumber);
            double result = 0;

            switch (operator) {
                case "+":
                    result = num1 + num2;
                    break;
                case "-":
                    result = num1 - num2;
                    break;
                case "*":
                    result = num1 * num2;
                    break;
                case "/":
                    if (num2 != 0) {
                        result = num1 / num2;
                    } else {
                        tvResult.setText("Error: Division by zero");
                        Toast.makeText(getContext(), "Cannot divide by zero", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    break;
            }

            String resultStr = formatResult(result);
            tvResult.setText(oldNumber + " " + operator + " " + currentNumber + " = " + resultStr);
            currentNumber = resultStr;
            tvExpression.setText(currentNumber);
            oldNumber = "";
            operator = "";
            isNewNumber = true;
        }
    }

    // Scientific Functions
    private void squareRoot() {
        if (!currentNumber.isEmpty()) {
            double num = Double.parseDouble(currentNumber);
            if (num >= 0) {
                double result = Math.sqrt(num);
                String resultStr = formatResult(result);
                tvResult.setText("√" + formatResult(num) + " = " + resultStr);
                currentNumber = resultStr;
                tvExpression.setText(currentNumber);
                isNewNumber = true;
            } else {
                tvResult.setText("Error: Invalid input");
                Toast.makeText(getContext(), "Cannot calculate square root of negative number", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void square() {
        if (!currentNumber.isEmpty()) {
            double num = Double.parseDouble(currentNumber);
            double result = num * num;
            String resultStr = formatResult(result);
            tvResult.setText("(" + formatResult(num) + ")² = " + resultStr);
            currentNumber = resultStr;
            tvExpression.setText(currentNumber);
            isNewNumber = true;
        }
    }

    private void cube() {
        if (!currentNumber.isEmpty()) {
            double num = Double.parseDouble(currentNumber);
            double result = num * num * num;
            String resultStr = formatResult(result);
            tvResult.setText("(" + formatResult(num) + ")³ = " + resultStr);
            currentNumber = resultStr;
            tvExpression.setText(currentNumber);
            isNewNumber = true;
        }
    }

    private void power() {
        if (!currentNumber.isEmpty()) {
            oldNumber = currentNumber;
            operator = "^";
            isNewNumber = true;
            tvResult.setText(oldNumber + " ^ ");
            Toast.makeText(getContext(), "Enter exponent and press =", Toast.LENGTH_SHORT).show();
        }
    }

    // Trigonometric Functions (in degrees)
    private void sin() {
        if (!currentNumber.isEmpty()) {
            double num = Double.parseDouble(currentNumber);
            double result = Math.sin(Math.toRadians(num));
            String resultStr = formatResult(result);
            tvResult.setText("sin(" + formatResult(num) + "°) = " + resultStr);
            currentNumber = resultStr;
            tvExpression.setText(currentNumber);
            isNewNumber = true;
        }
    }

    private void cos() {
        if (!currentNumber.isEmpty()) {
            double num = Double.parseDouble(currentNumber);
            double result = Math.cos(Math.toRadians(num));
            String resultStr = formatResult(result);
            tvResult.setText("cos(" + formatResult(num) + "°) = " + resultStr);
            currentNumber = resultStr;
            tvExpression.setText(currentNumber);
            isNewNumber = true;
        }
    }

    private void tan() {
        if (!currentNumber.isEmpty()) {
            double num = Double.parseDouble(currentNumber);
            double result = Math.tan(Math.toRadians(num));
            String resultStr = formatResult(result);
            tvResult.setText("tan(" + formatResult(num) + "°) = " + resultStr);
            currentNumber = resultStr;
            tvExpression.setText(currentNumber);
            isNewNumber = true;
        }
    }

    private void log() {
        if (!currentNumber.isEmpty()) {
            double num = Double.parseDouble(currentNumber);
            if (num > 0) {
                double result = Math.log10(num);
                String resultStr = formatResult(result);
                tvResult.setText("log₁₀(" + formatResult(num) + ") = " + resultStr);
                currentNumber = resultStr;
                tvExpression.setText(currentNumber);
                isNewNumber = true;
            } else {
                tvResult.setText("Error: Invalid input");
                Toast.makeText(getContext(), "Logarithm only for positive numbers", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void percentage() {
        if (!currentNumber.isEmpty()) {
            double num = Double.parseDouble(currentNumber);
            double result = num / 100;
            String resultStr = formatResult(result);
            tvResult.setText(formatResult(num) + "% = " + resultStr);
            currentNumber = resultStr;
            tvExpression.setText(currentNumber);
            isNewNumber = true;
        }
    }

    // Memory Functions
    private void memoryClear() {
        memoryValue = 0;
        Toast.makeText(getContext(), "Memory Cleared", Toast.LENGTH_SHORT).show();
    }

    private void memoryRecall() {
        currentNumber = formatResult(memoryValue);
        tvExpression.setText(currentNumber);
        tvResult.setText("MR = " + currentNumber);
        isNewNumber = true;
    }

    private void memoryAdd() {
        if (!currentNumber.isEmpty()) {
            double num = Double.parseDouble(currentNumber);
            memoryValue += num;
            Toast.makeText(getContext(), "Added to Memory: " + formatResult(memoryValue), Toast.LENGTH_SHORT).show();
        }
    }

    private void memorySubtract() {
        if (!currentNumber.isEmpty()) {
            double num = Double.parseDouble(currentNumber);
            memoryValue -= num;
            Toast.makeText(getContext(), "Subtracted from Memory: " + formatResult(memoryValue), Toast.LENGTH_SHORT).show();
        }
    }

    // Utility Functions
    private void clearAll() {
        currentNumber = "";
        oldNumber = "";
        operator = "";
        isNewNumber = true;
        tvExpression.setText("0");
        tvResult.setText("");
    }

    private void clearEntry() {
        currentNumber = "";
        tvExpression.setText("0");
        isNewNumber = true;
    }

    private void backspace() {
        if (!currentNumber.isEmpty()) {
            currentNumber = currentNumber.substring(0, currentNumber.length() - 1);
            if (currentNumber.isEmpty()) {
                tvExpression.setText("0");
            } else {
                tvExpression.setText(currentNumber);
            }
        }
    }

    private String formatResult(double result) {
        if (Double.isNaN(result) || Double.isInfinite(result)) {
            return "Error";
        }
        if (result == (long) result) {
            return String.valueOf((long) result);
        } else {
            String formatted = String.format("%.10f", result);
            formatted = formatted.replaceAll("0*$", "");
            formatted = formatted.replaceAll("\\.$", "");
            return formatted;
        }
    }
}