package com.example.advancedcalculator;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import java.util.HashMap;
import java.util.Map;

public class ConverterFragment extends Fragment {

    private Spinner spinnerCategory, spinnerFrom, spinnerTo;
    private EditText etInputValue;
    private TextView tvConvertedResult;
    private Button btnConvert;

    private String[] categories = {"Length", "Weight", "Temperature", "Area", "Volume", "Time", "Speed"};

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_converter, container, false);

        initViews(view);
        setupCategorySpinner();

        btnConvert.setOnClickListener(v -> performConversion());

        return view;
    }

    private void initViews(View view) {
        spinnerCategory = view.findViewById(R.id.spinnerCategory);
        spinnerFrom = view.findViewById(R.id.spinnerFrom);
        spinnerTo = view.findViewById(R.id.spinnerTo);
        etInputValue = view.findViewById(R.id.etInputValue);
        tvConvertedResult = view.findViewById(R.id.tvConvertedResult);
        btnConvert = view.findViewById(R.id.btnConvert);
    }

    private void setupCategorySpinner() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                updateUnitSpinners(categories[position]);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        updateUnitSpinners(categories[0]);
    }

    private void updateUnitSpinners(String category) {
        String[] units = getUnitsForCategory(category);

        ArrayAdapter<String> fromAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, units);
        fromAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFrom.setAdapter(fromAdapter);

        ArrayAdapter<String> toAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, units);
        toAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTo.setAdapter(toAdapter);
    }

    private String[] getUnitsForCategory(String category) {
        switch (category) {
            case "Length": return new String[]{"Meter", "Kilometer", "Centimeter", "Millimeter", "Mile", "Yard", "Foot", "Inch"};
            case "Weight": return new String[]{"Kilogram", "Gram", "Milligram", "Pound", "Ounce"};
            case "Temperature": return new String[]{"Celsius", "Fahrenheit", "Kelvin"};
            case "Area": return new String[]{"Square Meter", "Square Kilometer", "Square Foot", "Acre", "Hectare"};
            case "Volume": return new String[]{"Liter", "Milliliter", "Gallon", "Quart", "Cup"};
            case "Time": return new String[]{"Second", "Minute", "Hour", "Day", "Week"};
            case "Speed": return new String[]{"Meter/Second", "Kilometer/Hour", "Mile/Hour", "Knot"};
            default: return new String[]{};
        }
    }

    private void performConversion() {
        String category = categories[spinnerCategory.getSelectedItemPosition()];
        String fromUnit = spinnerFrom.getSelectedItem().toString();
        String toUnit = spinnerTo.getSelectedItem().toString();

        double inputValue;
        try {
            inputValue = Double.parseDouble(etInputValue.getText().toString());
        } catch (NumberFormatException e) {
            tvConvertedResult.setText("Invalid Input");
            return;
        }

        double result = convert(inputValue, category, fromUnit, toUnit);
        String formattedResult = (result == (long) result) ? String.valueOf((long) result) : String.format("%.6f", result).replaceAll("0*$", "").replaceAll("\\.$", "");
        tvConvertedResult.setText(formattedResult);
    }

    private double convert(double value, String category, String from, String to) {
        if (category.equals("Temperature")) {
            return convertTemperature(value, from, to);
        }

        double toBase = getConversionFactor(category, from);
        double fromBase = getConversionFactor(category, to);
        return (value * toBase) / fromBase;
    }

    private double getConversionFactor(String category, String unit) {
        switch (category) {
            case "Length":
                switch (unit) {
                    case "Meter": return 1;
                    case "Kilometer": return 1000;
                    case "Centimeter": return 0.01;
                    case "Millimeter": return 0.001;
                    case "Mile": return 1609.34;
                    case "Yard": return 0.9144;
                    case "Foot": return 0.3048;
                    case "Inch": return 0.0254;
                }
                break;
            case "Weight":
                switch (unit) {
                    case "Kilogram": return 1;
                    case "Gram": return 0.001;
                    case "Milligram": return 0.000001;
                    case "Pound": return 0.453592;
                    case "Ounce": return 0.0283495;
                }
                break;
            case "Area":
                switch (unit) {
                    case "Square Meter": return 1;
                    case "Square Kilometer": return 1000000;
                    case "Square Foot": return 0.092903;
                    case "Acre": return 4046.86;
                    case "Hectare": return 10000;
                }
                break;
            case "Volume":
                switch (unit) {
                    case "Liter": return 1;
                    case "Milliliter": return 0.001;
                    case "Gallon": return 3.78541;
                    case "Quart": return 0.946353;
                    case "Cup": return 0.236588;
                }
                break;
            case "Time":
                switch (unit) {
                    case "Second": return 1;
                    case "Minute": return 60;
                    case "Hour": return 3600;
                    case "Day": return 86400;
                    case "Week": return 604800;
                }
                break;
            case "Speed":
                switch (unit) {
                    case "Meter/Second": return 1;
                    case "Kilometer/Hour": return 0.277778;
                    case "Mile/Hour": return 0.44704;
                    case "Knot": return 0.514444;
                }
                break;
        }
        return 1;
    }

    private double convertTemperature(double value, String from, String to) {
        double celsius;
        switch (from) {
            case "Celsius": celsius = value; break;
            case "Fahrenheit": celsius = (value - 32) * 5/9; break;
            case "Kelvin": celsius = value - 273.15; break;
            default: celsius = value;
        }
        switch (to) {
            case "Celsius": return celsius;
            case "Fahrenheit": return celsius * 9/5 + 32;
            case "Kelvin": return celsius + 273.15;
            default: return celsius;
        }
    }
}